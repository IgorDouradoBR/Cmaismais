#ifndef __BLOCKSPACE_H
#define __BLOCKSPACE_H

#include <vector>
#include <memory>
#include "Linha.h"


class BlockSpace
{
private:
	std::vector < std::vector<int>> _block_sections;
	int _width;
	float _height;
	int _opcao;
	int _nsections;
	float _sectionSize;
public:
	BlockSpace();
	BlockSpace(float width, float height, int n_sections, int opcao);
	~BlockSpace();

	void Init(float width, float height, int n_sections, int opcao);
	void InsertLine(Linha& line, int index);

	std::vector<int> GetLinesIndexBySection(int section) const;
	std::vector < std::vector<int>> GetAllBlocks() const;
	void DrawSections();
	int GetNSections() const;

};

#endif // !__BLOCKSPACE_H
